package com.yptlauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF100D18)
private val Panel = Color(0xFF21172E)
private val Purple = Color(0xFF8B3DCC)
private val Lilac = Color(0xFFC69AF5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YPTApp() }
    }
}

@Composable
fun YPTApp() {
    var page by remember { mutableStateOf("Home") }
    var code by remember { mutableStateOf("-- Welcome to YPTLauncher\\nprint(\\"Hello YPT!\\")") }
    var status by remember { mutableStateOf("Ready") }
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lilac, secondary = Purple, background = Bg, surface = Panel
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Editor", "Scripts", "Console", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(when(item) {
                                "Home" -> Icons.Default.Home
                                "Editor" -> Icons.Default.Code
                                "Scripts" -> Icons.Default.Folder
                                "Console" -> Icons.Default.Terminal
                                else -> Icons.Default.Settings
                            }, contentDescription = item)
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Lilac, selectedTextColor = Lilac,
                            indicatorColor = Purple.copy(alpha = .25f),
                            unselectedIconColor = Color.LightGray
                        )
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Purple, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text("YPT", color = Color.White, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("YPTLauncher", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("BLACK & PURPLE EDITION", color = Lilac, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(22.dp))
                when(page) {
                    "Home" -> {
                        Text("Welcome back", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Your scripts. Your commands. Your control.", color = Lilac)
                        Spacer(Modifier.height(22.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("EXTERNAL GAMES", color = Lilac, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Roblox", color = Color.White, fontSize = 20.sp)
                                Text("Open the official Roblox Android app.", color = Color.LightGray)
                                Spacer(Modifier.height(14.dp))
                                Button(onClick = {
                                    val launch = context.packageManager.getLaunchIntentForPackage("com.roblox.client")
                                    if (launch != null) context.startActivity(launch)
                                    else {
                                        val store = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.roblox.client"))
                                        context.startActivity(store)
                                    }
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                                    Icon(Icons.Default.PlayArrow, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("LAUNCH ROBLOX", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("FLOATING BUBBLE", color = Lilac, fontWeight = FontWeight.Bold)
                                Text("Use your supplied image as a movable overlay button.", color = Color.LightGray)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = {
                                    if (Settings.canDrawOverlays(context)) {
                                        context.startService(Intent(context, FloatingBubbleService::class.java))
                                        status = "Floating bubble enabled"
                                    } else {
                                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")))
                                        status = "Grant overlay permission, then tap again"
                                    }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.BubbleChart, null)
                                    Spacer(Modifier.width(8.dp)); Text("ENABLE FLOATING BUBBLE")
                                }
                                Text(status, color = Lilac, fontSize = 12.sp)
                            }
                        }
                    }
                    "Editor" -> {
                        Text("LuaU Editor", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Write and save code for environments you own or are authorized to test.", color = Lilac)
                        Spacer(Modifier.height(12.dp))
                        BasicTextField(value = code, onValueChange = { code = it },
                            modifier = Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFE9D8FF), fontSize = 14.sp))
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { status = "Editor content is ready to save; runtime execution is not included in this MVP." },
                            colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth()) {
                            Text("CHECK / SAVE DRAFT")
                        }
                        Text(status, color = Lilac, fontSize = 12.sp)
                    }
                    "Scripts" -> {
                        Text("Script Hub", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Your local script library", color = Lilac)
                        Spacer(Modifier.height(14.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("No scripts imported yet", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Import and organize .lua / .luau files in a future build.", color = Color.LightGray)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Compatibility checks will be static checks only; they cannot guarantee a script works in every app.", color = Lilac)
                    }
                    "Console" -> {
                        Text("Console", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF09070D), RoundedCornerShape(12.dp)).padding(14.dp)) {
                            Text("> YPTLauncher initialized\\n> Android standalone mode\\n> No external app injection enabled", color = Color(0xFFB9F6CA), fontSize = 13.sp)
                        }
                    }
                    else -> {
                        Text("Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("Theme: Black & Purple", color = Lilac)
                        Text("Floating overlay requires Android permission.", color = Color.LightGray)
                        Text("Roblox launcher opens the official installed app.", color = Color.LightGray)
                        Text("No key system.", color = Color.LightGray)
                    }
                }
            }
        }
    }
}
