# YPTLauncher Android MVP

## Qué incluye
- Interfaz Android nativa en negro y morado (Jetpack Compose).
- Botón para abrir Roblox oficial (`com.roblox.client`) o su ficha de Google Play si no está instalado.
- Botón flotante Android usando exactamente el archivo de imagen proporcionado (`ypt_bubble.webp`), recortado circularmente en pantalla sin alterar el archivo original.
- Editor de borradores LuaU, Script Hub/Console/Settings de primera versión.

## Límites de esta versión
- El editor guarda el texto solo durante la sesión; persistencia/importación se añadirá después.
- No incorpora un runtime LuaU.
- No inyecta código en Roblox ni en otras APK. Android aísla las aplicaciones; la superposición no concede acceso interno a ellas.
- El toque del globo muestra un aviso; conectar el globo con el menú completo requiere una segunda iteración de navegación/overlay.

## Abrir y compilar
1. Descomprime el proyecto.
2. Abre la carpeta `YPTLauncher` en Android Studio (Giraffe o posterior; recomendado Koala/Ladybug).
3. Deja que Gradle sincronice y descarga el Android SDK 35 si se solicita.
4. Selecciona `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

Requiere JDK 17 y conexión a Internet durante la primera sincronización de Gradle.
